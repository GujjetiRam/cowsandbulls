export class Triesinfo {
     
    constructor(public word:string,public bulls:number,public cows:number) { }
}
